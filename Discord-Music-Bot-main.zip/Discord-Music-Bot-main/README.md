>![](https://cdn.discordapp.com/attachments/675669552796925987/827826023822917692/unknown.png)

# Discord-Music-Bot


(UPDATED : 13/12/20)
`(UPDATE  : 3/4/21) : Updated the packages and fixed some bugs, NO API required now.`

JOIN THE SERVER : https://withwin.in/dbd
